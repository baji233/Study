package system.vo;

public class BookInfo {
    String BName;
    String BId;
    String CId;
    String Author;
    String Pubish;
    String PDate;
    int Price;


    public static void main(String[] args) {
        String s="10";
        int i= Integer.parseInt(s);
        System.out.println(i);
    }
}
